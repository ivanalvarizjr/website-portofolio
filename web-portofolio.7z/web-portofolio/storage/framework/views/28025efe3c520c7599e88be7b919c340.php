<h3> <?php echo e($judul); ?> </h3>
<a href="<?php echo e(route('anggota.create')); ?>">
    <button type="button">Tambah</button>
</a>
<table border="1" width="60%">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>HP</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td> <?php echo e($loop->iteration); ?> </td>
            <td> <?php echo e($row->nama); ?> </td>
            <td> <?php echo e($row->hp); ?> </td>
            <td>
                <a href="<?php echo e(route('anggota.edit', $row->id)); ?>" style="display: inline-block;">
                    <button type="button">Ubah</button>
                </a>
                <form action="<?php echo e(route('anggota.destroy', $row->id)); ?>" method="POST" style="display: inline-block;">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<form action="<?php echo e(route('anggota.destroy', $row->id)); ?>" method="POST" style="display: inline-block;">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
    <button type="submit">Hapus</button>
</form><?php /**PATH C:\laravel\tutor laravel\belajarCRUD\belajarCRUD\resources\views/v_anggota/index.blade.php ENDPATH**/ ?>