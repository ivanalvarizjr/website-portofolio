<h3> <?php echo e($judul); ?> </h3>
<form action="<?php echo e(route('anggota.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label>Nama</label><br>
    <input type="text" name="nama" id="" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan Nama Lengkap"
        class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback alert-danger" role="alert">
            <?php echo e($message); ?>

        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    //tulisan merah ini adalah code invalid-feedback berfungsi dapat memberikan umpan balik

    <p></p>
    <label>HP</label><br>
    <input type="text" name="hp" id="" value="<?php echo e(old('hp')); ?>" placeholder="Masukkan Nomor HP"
        class="form-control <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>      <span class="invalid-feedback alert-danger" role="alert">
            <?php echo e($message); ?>

        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    //tulisan merah ini adalah code invalid-feedback berfungsi dapat memberikan umpan balik

    <p></p>
    <button type="submit">Simpan</button>
    <a href="<?php echo e(route('anggota.index')); ?>">
        <button type="button">Batal</button>
    </a>
</form><?php /**PATH C:\laravel\tutor laravel\belajarCRUD\belajarCRUD\resources\views/v_anggota/create.blade.php ENDPATH**/ ?>